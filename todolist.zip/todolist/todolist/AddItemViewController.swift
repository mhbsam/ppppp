//
//  AddItemViewController.swift
//  todolist
//
//  Created by Mac on 3/21/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

protocol AddItemViewControllerDelegate: class {
    func SaveItem(with item: [Any])
}


class AddItemViewController: UIViewController {
    
    weak var delegate: AddItemViewControllerDelegate?

    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var notesTextView: UITextView!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //sending new item information as a list to todolist view controller, using delegate
    @IBAction func additemButtonPressed(_ sender: UIButton) {
        let title = titleTextField.text
        let notes = notesTextView.text
        let due_date = datePicker.date
        let item = [title!, notes!, due_date] as [Any]
        
        delegate?.SaveItem(with: item)
    }
}
