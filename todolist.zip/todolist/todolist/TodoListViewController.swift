//
//  ViewController.swift
//  todolist
//
//  Created by Mac on 3/21/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit
import CoreData

class TodoListViewController: UIViewController {
    var todoList = [TodoItem]()
    @IBOutlet weak var todoTableView: UITableView!
    
    //running functions as view loads
    override func viewDidLoad() {
        super.viewDidLoad()
        todoTableView.dataSource = self
        todoTableView.delegate = self
        fetchAllItems()
    }

    //segue preoeration
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let navigationController = segue.destination as! UINavigationController
        let add = navigationController.topViewController as! AddItemViewController
        add.delegate = self
    }
    
    //Required variable to make changes to Core Data
    let ManagedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    //requesting to fetch all todolist items
    func fetchAllItems(){
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "TodoItem")
        do{
            let result = try ManagedObjectContext.fetch(request)
            todoList = result as! [TodoItem]
        }catch{
            print(error)
        }
    }
}



extension TodoListViewController: UITableViewDataSource{
    
    //returning number of rows in todolist view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoList.count
    }
    
    //filling cell labels with required information
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath) as! ItemTableViewCell
        let item = todoList[indexPath.row]
        cell.titleLabel.text = item.title
        cell.notesLabel.text = item.notes
        
        //converting date to string format
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let dateString = dateFormatter.string(from: item.due_date as! Date)
        cell.dateLabel.text = dateString
        
        return cell
    }
}


extension TodoListViewController: AddItemViewControllerDelegate{
    
    //sending the new item to core data and saving it =
    func SaveItem(with item: [Any]){
        let todoItem = NSEntityDescription.insertNewObject(forEntityName: "TodoItem", into: ManagedObjectContext) as! TodoItem
        todoItem.title = String(describing: item[0])
        todoItem.notes = String(describing: item[1])
        todoItem.due_date = (item[2] as! NSDate)
        todoItem.completed = false
        do{
            try ManagedObjectContext.save()
        }catch{
            print(error)
        }
        
        //append new item to todolist, reoad the table, and dismiss the view
        todoList.append(todoItem)
        todoTableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
}

//selecting a row and adding a checkmark, if the status is completed
extension TodoListViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let todoItem = self.todoList[indexPath.row]
        todoItem.completed = !todoItem.completed
        do{
            try ManagedObjectContext.save()
        }catch{
            print(error)
        }
        print("status is \(todoItem.completed)")
        
        let cell = tableView.cellForRow(at: indexPath)
        if todoItem.completed {
            cell?.accessoryType = .checkmark
        }else{
            cell?.accessoryType = .none
        }
    }
}

