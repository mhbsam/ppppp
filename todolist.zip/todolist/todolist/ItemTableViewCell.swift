//
//  ItemTableViewCell.swift
//  todolist
//
//  Created by Mac on 3/21/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ItemTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var notesLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
