//
//  ViewController.swift
//  bucket_list
//
//  Created by Mac on 3/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit
import CoreData

class BucketListViewController: UITableViewController, AddItemViewControllerDelegate {
    var items = [BucketListItem]()
    
    let ManagedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllItems()
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
        
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListItemCell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row].text!
        return cell
    }
    
    
    //used to be listening for tapping anywhere on the row, to edit a row
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Selected")
    }
    
    //listening for accessory button tap to send us to edit view
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        performSegue(withIdentifier: "EditItemSegue", sender: indexPath)
    }
    
    //swiping to delete a row
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        //removing from database and saving it
        let item = items[indexPath.row]
        ManagedObjectContext.delete(item)
        do{
            try ManagedObjectContext.save()
        } catch{
            print(error)
        }
        
        //removing from table view and reloading the data
        items.remove(at: indexPath.row)
        tableView.reloadData()

    }
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddItemSegue"{
            let navigationController = segue.destination as! UINavigationController
            let addItemTableViewController = navigationController.topViewController as! AddItemTableViewController
            addItemTableViewController.delegate = self
            
        }else if segue.identifier == "EditItemSegue"{
            let navigationController = segue.destination as! UINavigationController
            let addItemTableViewController = navigationController.topViewController as! AddItemTableViewController
            addItemTableViewController.delegate = self
            
            let indexPath = sender as! NSIndexPath
            let item = items[indexPath.row]
            addItemTableViewController.item = item.text!
            addItemTableViewController.indexPath = indexPath
        }
    }
    
        func cancelButtonPressed(by controller: AddItemTableViewController) {
            dismiss(animated: true, completion: nil)
        }
    
    
    
        
    func itemSaved(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?) {
        
        if let ip = indexPath{
            let item = items[ip.row]
            item.text = text
            
        }else{
            let item = NSEntityDescription.insertNewObject(forEntityName: "BucketListItem", into: ManagedObjectContext) as! BucketListItem
            item.text = text
            items.append(item)
        }
        
        do{
            try ManagedObjectContext.save()
        }catch{
            print(error)
        }
        
        
        tableView.reloadData()
        dismiss(animated: true, completion: nil)
        }
    
    
    
    func fetchAllItems(){
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "BucketListItem")
        do{
            let result = try ManagedObjectContext.fetch(request)
            items = result as! [BucketListItem]

        }catch{
            print(error)
        }
    }
    
    
    
}


// In order to create a fucntioning cancel button, which dismisses the view following steps has been followed:

//--------------- First Step -----------------------

// 1- create cancel delegate file
// 2- inside delegate file define protocol and its requirement which is a function that can be invoked by pressing the cencell button by a controller

//example:
//File -> New -> File... -> swift -> CancelButtonDelegate.swift
// import UIKit
// protocol CancelButtonDelegate: class {
// func cancelButtonPressed(by controller: UIViewController)
// }

//--------------- Second Step -----------------------

// On cancel controller:
// 3- Define delegate as a variable
// 4- Connect cancel button from the storyboard to cancel controller (if not already connected!)
// 5- inside the cancel button pressed function call the delegate and the function inside its protocol

//example:
// weak var delegate: CancelButtonDelegate?
//    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
// delegate?.cancelButtonPressed(by: self)
// }

//--------------- Third Step -------------------------
// on the top view controller( The view we want to be after dismissing "cancel controller")
// 1- import cancel delegate
// 2- 






