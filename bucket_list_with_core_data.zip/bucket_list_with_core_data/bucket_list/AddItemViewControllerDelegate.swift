//
//  AddItemViewControllerDelegate.swift
//  bucket_list
//
//  Created by Mac on 3/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

protocol AddItemViewControllerDelegate: class {
    func itemSaved(by controller: AddItemTableViewController, with text: String, at indexPath: NSIndexPath?)
    func cancelButtonPressed(by controller: AddItemTableViewController)
    }
