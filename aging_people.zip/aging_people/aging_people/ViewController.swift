//
//  ViewController.swift
//  aging_people
//
//  Created by Mac on 3/14/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    let list = ["Rect", "Realize", "Tri", "Light", "Column", "TV"]

    
    @IBOutlet weak var tableViewObject: UITableView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewObject.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "ProtoCell", for: indexPath)
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "ProtoCell")
        let rand = String(Int(arc4random_uniform(90)+5))
        cell.textLabel?.text = list[indexPath.row]
        cell.detailTextLabel?.text = rand
        return cell
    }
}

