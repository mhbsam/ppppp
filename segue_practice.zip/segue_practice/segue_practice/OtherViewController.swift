//
//  OtherViewController.swift
//  segue_practice
//
//  Created by Mac on 3/15/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class OtherViewController: UIViewController {
    @IBOutlet weak var outputLable: UILabel!
    var output : String?

    override func viewDidLoad() {
        super.viewDidLoad()
        outputLable.text = output
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func dissmissButtonPressed(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }

}
