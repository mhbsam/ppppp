//
//  ViewController.swift
//  rainbow_road
//
//  Created by Mac on 3/14/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    let colors : [UIColor] = [.red, .orange, .yellow, .green, .blue, .purple]
    @IBOutlet weak var TableViewObject: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableViewObject.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return colors.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "RainbowCell", for: indexPath)
        cell.backgroundColor = colors[indexPath.row]
        return cell
    }

}

