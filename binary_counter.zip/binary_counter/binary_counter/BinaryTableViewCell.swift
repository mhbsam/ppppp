//
//  BinaryTableViewCell.swift
//  binary_counter
//
//  Created by Mac on 3/21/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import Foundation
import UIKit

protocol BinaryTableViewCellDelegate: class {
    func valueChangedBy(value: Int)
}

class BinaryTableViewCell: UITableViewCell{
    
    weak var delegate: BinaryTableViewCellDelegate?
    @IBOutlet weak var valueLable: UILabel!
    
    @IBAction func valueButtonPressed(_ sender: UIButton) {
        var value = Int(valueLable.text!)
        
        if sender.titleLabel!.text == "-"{
            value = -value!
        }
        
        delegate?.valueChangedBy(value: value!)
        print("delegate in TableViewCell------\(delegate)")
    }
}
