//
//  ViewController.swift
//  binary_counter
//
//  Created by Mac on 3/21/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    @IBOutlet weak var totalLabel: UILabel!
    var total = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}



extension ViewController: UITableViewDataSource{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 16
    }
    
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BinaryCell", for: indexPath) as! BinaryTableViewCell
        cell.delegate = self
        cell.valueLable.text = String(describing: pow(10, indexPath.row))
        print("self in tableviewDataSource is \(self)")
        print("cell.delegate in tableviewDataSource is \(cell.delegate)")


        return cell
    }
}


    


extension ViewController: BinaryTableViewCellDelegate{
    func valueChangedBy(value: Int) {
        
        self.total += value
        totalLabel.text = "Total: \(self.total)"
    }
}

